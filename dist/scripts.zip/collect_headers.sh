#!/usr/bin/env bash

set -euo pipefail
trap "echo 'Error o salida forzada, limpiando...'; rm -f out/tmp_*" EXIT


if [[ -z "${TARGETS:-}" ]]; then
  echo "Debes definir TARGETS (ej: export TARGETS='https://example.com https://openai.com')" >&2
  exit 1
fi

HEADERS=("Strict-Transport-Security" "Content-Security-Policy" "X-Content-Type-Options" "Access-Control-Allow-Origin")

report="out/security_report.csv"
echo "host,${HEADERS[*]}" | tr ' ' ',' > "$report"

for url in $TARGETS; do
  host=$(echo "$url" | awk -F/ '{print $3}')
  file="out/headers_${host}.txt"
  echo "Consultando $url ..."
  curl -s -I "$url" > "$file"

  results=()
  for header in "${HEADERS[@]}"; do
    if grep -qi "^$header" "$file"; then
      results+=("OK")
    else
      results+=("FAIL")
    fi
  done

  echo "$host,${results[*]}" | tr ' ' ',' >> "$report"
done

echo "Reporte generado en $report"
